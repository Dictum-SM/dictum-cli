# Terraform

DSM manages terraform resources by performing `terraform init` followed by `terraform <apply/delete>` everytime that it manages a resource. 

