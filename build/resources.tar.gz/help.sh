#!/bin/bash

more ${TMPDIR}/docs/help.txt